const functions = require("firebase-functions");
const admin = require("firebase-admin");
const emailjs = require("emailjs-com");

admin.initializeApp();
// // Create and Deploy Your First Cloud Functions
// // https://firebase.google.com/docs/functions/write-firebase-functions
//
// exports.helloWorld = functions.https.onRequest((request, response) => {
//   functions.logger.info("Hello logs!", {structuredData: true});
//   response.send("Hello from Firebase!");
// });

exports.scheduledAlerts = functions.pubsub
  .schedule("every 12 hours")
  .onRun(async (context) => {
    const promises = [];
    const users = await getUsers();

    users.forEach(async (user) => {
      promises.push(
        await emailjs.send(
          "service_r0cymvo",
          "template_r5vz98f",
          {
            to: user.email,
            name: user.firstName,
          },
          "8AMWv7Z4J14U10EYv"
        )
      );
    });

    return Promise.all(promises);
  });
const getUsers = async () => {
  const users = [];
  const m = await admin
    .firestore()
    .collection("users")
    .where({
      allowNotifications: true,
    })
    .get();

  m.docs.forEach((doc) => {
    users.push({ id: doc.id, ...doc.data() });
  });

  return users.map((user) => user.email);
};
