import firebase, { firestore } from "../firebase";

export const createUser = async (user) => {
  return firestore.collection("users").add({
    firstName: user.firstName,
    lastName: user.lastName,
    email: user.email,
    age: user.age,
    gender: user.gender,
    chronicDisease: user.chronicDisease,
    familyDisease: user.familyDisease,
    smoking: user.smoking,
    drinking: user.drinking,
    allowNotification: user.allowNotification,
    created: firebase.firestore.FieldValue.serverTimestamp(),
  });
};

