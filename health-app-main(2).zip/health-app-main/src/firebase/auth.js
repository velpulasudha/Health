import { auth } from "../firebase";

export const logout = async () => {
  return auth.signOut();
};
