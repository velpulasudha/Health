import firebase, { firestore } from "../firebase";

export const addRating = async (category, rating) => {
  const ratings = await getRatings(category);
  ratings.push(rating);
  return firestore.collection("categories").doc(category).update({
    ratings,
  });
};

export const getRatings = async (category) => {
  const doc = await firestore.collection("categories").doc(category).get();

  return doc.data().ratings;
};
