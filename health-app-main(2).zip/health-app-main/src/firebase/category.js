import firebase, { firestore } from "../firebase";

export const getCategories = async () => {
  const { docs } = await firestore.collection("categories").get();

  const categories = docs.map((doc) => doc.data());

  const modified = categories.map((category) => {
    return {
      ...category,
      rating: getAverage(category.ratings),
      total: category.ratings.length,
    };
  });

  const m = modified.sort(
    (a, b) => parseFloat(b.rating) - parseFloat(a.rating)
  );

  return m;
};

const getAverage = (array) => {
  let total = 0;
  if (array.length === 0) return 0;
  array.forEach((element) => {
    total += element;
  });

  return parseFloat(total / array.length).toFixed(2);
};
