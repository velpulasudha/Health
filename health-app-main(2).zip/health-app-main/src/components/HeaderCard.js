import { Typography, Paper, Grid } from "@mui/material";
import { capitalizeFirst } from "../helper";
import { useNavigate } from "react-router-dom";
import StarIcon from "@mui/icons-material/Star";

const HeaderCard = ({ title, url, image, rating = 0, number = 0 }) => {
  const navigate = useNavigate();
  return (
    <Grid item md={6} xs={12} onClick={() => navigate(url)}>
      <Paper
        sx={{
          // height: "12rem",
          padding: 5,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
        }}
        elevation={5}
      >
        <Typography
          sx={{
            textAlign: "center",
            fontWeight: "bold",
            fontSize: "1rem",
            color: "gray",
          }}
        >
          {capitalizeFirst(title)}
        </Typography>
        <img
          src={image}
          alt="icon"
          style={{ width: 50, height: 50, margin: 10 }}
        />
        <div style={{ display: "flex" }}>
          <StarIcon sx={{ color: "#f7d80a", marginRight: 0.5 }} />
          <Typography sx={{ marginRight: 0.5 }}>{rating}</Typography>
          <Typography sx={{ color: "gray" }}>({number})</Typography>
        </div>
      </Paper>
    </Grid>
  );
};

export default HeaderCard;
