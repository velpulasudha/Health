import React, { useState } from "react";
import { Button } from "@mui/material";
import Rating from "../Rating";

const Covid = () => {
  const [covid, setCovid] = useState("None");
  const [message, setMessage] = useState("");
  const [url, setUrl] = useState("");

  let covidsymp = (event) => {
    event.preventDefault();
    if (covid == "None") {
      alert("Please select valid symptom");
    } else if (covid === "Symptomatic & Asymptomatic") {
      setUrl(
        "https://firebasestorage.googleapis.com/v0/b/health-info-app-22b13.appspot.com/o/COVID%2FCOVID%2Bve.pdf?alt=media&token=b9e34e39-d9a9-4b9a-ab93-d87cbee59df7"
      );
      setMessage("Symptomatic & Asymptomatic");
    }
  };

  return (
    <div>
      <div className="container">
        <b>
          <h2 className="head2">Covid 19</h2>
        </b>
        <form onSubmit={covidsymp} className="p-4 box">
          <div className="form-body">
            <div className="covid">
              <label className="form__label" for="covid">
                <b>Select_Symptom</b>
              </label>

              <select
                type="text"
                onChange={(e) => setCovid(e.target.value)}
                placeholder=""
                value={covid}
              >
                <option value={"None"}>-None-</option>
                <option value={"Symptomatic & Asymptomatic"}>
                  Symptomatic & Asymptomatic
                </option>
              </select>
            </div>
            <div className="head2">
              <button className="form_btn" type="submit">
                Submit
              </button>
            </div>
          </div>
        </form>

        <div className="center">
          <h3 className="head2">Covid-19 Symptom: {covid}</h3>
          <h3>{message}</h3>
          <Button
            disabled={!message}
            variant="contained"
            color="success"
            size="large"
            onClick={() => window.open(url, "_blank")}
          >
            See Your Results
          </Button>
        </div>
        <Rating category={"covid"} disabled={!message} />
      </div>
    </div>
  );
};
export default Covid;
