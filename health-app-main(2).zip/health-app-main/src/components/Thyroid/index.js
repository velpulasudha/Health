import React, { useState } from "react";
import { Button } from "@mui/material";
import Rating from "../Rating";

const Thyroid = () => {
  const [thyroid, setThyroid] = useState("None");
  const [message, setMessage] = useState("");
  const [url, setUrl] = useState("");

  let thyroidtype = (event) => {
    event.preventDefault();
    if (thyroid === "None") {
      alert("Please select valid symptom");
    } else if (thyroid === "Hypothyroidism") {
      setUrl(
        "https://firebasestorage.googleapis.com/v0/b/health-info-app-22b13.appspot.com/o/TD%2FHypothyroidism.pdf?alt=media&token=90a07e32-3bf8-4b9e-93dc-c1d1fb2683e7"
      );
      setMessage("Hypothyroidism");
    } else if (thyroid === "Hyperthyroidism") {
      setUrl(
        "https://firebasestorage.googleapis.com/v0/b/health-info-app-22b13.appspot.com/o/TD%2FHyperthyroidism.pdf?alt=media&token=97291f4a-5f04-42f5-8900-3d91a9caa2bc"
      );
      setMessage("Hyperthyroidism");
    }
  };

  return (
    <div>
      <div className="container">
        <b>
          <h2 className="head2">Thyroid</h2>
        </b>
        <form onSubmit={thyroidtype} className="p-4 box">
          <div className="form-body">
            <div className="thyroid">
              <label className="form__label" for="thyroid">
                <b>Select Type</b>
              </label>

              <select type="text" onChange={(e) => setThyroid(e.target.value)}>
                <option value={"None"}>None</option>
                <option>Hyperthyroidism</option>
                <option>Hypothyroidism</option>
              </select>
            </div>
            <div className="head2">
              <button className="form_btn" type="submit">
                Submit
              </button>
            </div>
          </div>
        </form>

        <div className="center">
          <h3 className="head2">Thyroid Type: {thyroid}</h3>
          <p>{message}</p>
          <Button
            disabled={!message}
            variant="contained"
            color="success"
            size="large"
            onClick={() => window.open(url, "_blank")}
          >
            See Your Results
          </Button>
        </div>
        <Rating category={"thyroid"} disabled={!message}/>
      </div>
    </div>
  );
};
export default Thyroid;
