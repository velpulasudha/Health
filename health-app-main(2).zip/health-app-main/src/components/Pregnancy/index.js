import React, { useState } from "react";
import { Button } from "@mui/material";
import Rating from "../Rating";

const Pregnancy = () => {
  const [pregnancy, setPregnancy] = useState(1);
  const [url, setUrl] = useState("");
  const [message, setMessage] = useState("");

  let pregweeks = (event) => {
    event.preventDefault();
    if (pregnancy <= 0) {
      alert("Please enter valid pregnancy weeks");
    } else if (pregnancy > 40) {
      alert("Please enter valid pregnancy weeks");
    } else {
      if (pregnancy <= 12) {
        setUrl(
          "https://firebasestorage.googleapis.com/v0/b/health-info-app-22b13.appspot.com/o/PY%2FTrimester-1.pdf?alt=media&token=83fa1406-5041-4bee-afbf-e1b58a9e938d"
        );
        setMessage("Trimester 1");
      } else if (pregnancy > 12 && pregnancy <= 24) {
        setUrl(
          "https://firebasestorage.googleapis.com/v0/b/health-info-app-22b13.appspot.com/o/PY%2FTrimester-2.pdf?alt=media&token=0c4c01ef-3c60-4811-a650-f792905d9b67"
        );
        setMessage("Trimester 2");
      } else if (pregnancy > 24 && pregnancy <= 40) {
        setUrl(
          "https://firebasestorage.googleapis.com/v0/b/health-info-app-22b13.appspot.com/o/PY%2FTrimester-3.pdf?alt=media&token=be5873c4-0105-451b-8131-24b7e2517e49"
        );
        setMessage("Trimester 3");
      }
    }
  };

  return (
    <div>
      <div className="container">
        <b>
          <h2 className="head2">Pregnancy</h2>
        </b>
        <form onSubmit={pregweeks} className="p-4 box">
          <div className="form-body">
            <div className="pregnancy">
              <label className="form__label" for="pregnancy">
                <b>Pregnancy(Weeks)</b>
              </label>
              <input
                type="number"
                name=""
                id="pregnancy"
                value={pregnancy}
                className="form__input"
                onChange={(e) => setPregnancy(e.target.value)}
                placeholder="Enter Weeks"
                max={40}
              />
            </div>
            <div className="head2">
              <button className="form_btn" type="submit">
                Submit
              </button>
            </div>
          </div>
        </form>

        <div className="center">
          <h3 className="head2">Pregnancy Weeks: {pregnancy}</h3>
          <h3>{message}</h3>
          <Button
            disabled={!message}
            variant="contained"
            color="success"
            size="large"
            onClick={() => window.open(url, "_blank")}
          >
            See Your Results
          </Button>
        </div>
        <Rating category={"pregnancy"} disabled={!message}/>
      </div>
    </div>
  );
};
export default Pregnancy;
