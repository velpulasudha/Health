import React, { useState } from "react";
import { Button, Rating, Typography, Box } from "@mui/material";
import { addRating } from "../firebase/ratings";

const RatingMain = ({ category, disabled = false }) => {
  const [rating, setRating] = useState(0);

  const add = async () => {
    try {
      await addRating(category, rating);
      alert(`You gave this category a ${rating} rating`);
    } catch (error) {}
  };
  return (
    <>
      {!disabled && (
        <Box sx={{ marginY: 3 }}>
          <Typography>Please Rate this Category</Typography>
          <Box sx={{ display: "flex" }}>
            <Rating
              title="Rating"
              name="simple-controlled"
              value={rating}
              onChange={(event, newValue) => {
                setRating(newValue);
              }}
            />
            <h5>{rating}</h5>
          </Box>
          <Button
            variant="contained"
            color="warning"
            size="small"
            onClick={add}
          >
            Submit Rating
          </Button>
        </Box>
      )}
    </>
  );
};

export default RatingMain;
