import React, { useState } from "react";
import { Button } from "@mui/material";
import Rating from "../Rating";

const Gastric = () => {
  const [gastric, setgastric] = useState("None");
  const [url, setUrl] = useState("");
  const [message, setMessage] = useState("");

  let gastricsymp = (event) => {
    //prevent submitting
    event.preventDefault();
    if (gastric === "None") {
      alert("Please select valid symptom");
    } else if (gastric === "Abdominal Pain") {
      setUrl(
        "https://firebasestorage.googleapis.com/v0/b/health-info-app-22b13.appspot.com/o/GP%2Fabdominal%20pain.pdf?alt=media&token=3744faee-b5f6-41dd-a379-661a3e1c2b42"
      );
      setMessage("Abdominal Pain");
    } else if (gastric === "GERD") {
      setMessage("GERD");
      setUrl(
        "https://firebasestorage.googleapis.com/v0/b/health-info-app-22b13.appspot.com/o/GP%2FGERD.pdf?alt=media&token=5ee29d4e-10db-4cfb-9f83-53b247049ad1"
      );
    } else if (gastric === "Irritable Bowel Syndrome") {
      setUrl(
        "https://firebasestorage.googleapis.com/v0/b/health-info-app-22b13.appspot.com/o/GP%2FIrritable%20Bowel%20Syndrome.pdf?alt=media&token=580cc5de-981a-4681-8b7c-b7fbdf8f9e52"
      );
      setMessage("Irritable Bowel Syndrome");
    } else {
      setMessage("Invalid choice");
    }
  }

  return (
    <div>
      <div className="container">
        <b>
          <h2 className="head2">Gastric Problems</h2>
        </b>
        <form onSubmit={gastricsymp} className="p-4 box">
          <div className="form-body">
            <div className="gastric">
              <label className="form__label" for="gastric">
                <b>Select_Gastric_Symptom</b>
              </label>

              <select
                type="text"
                onChange={(e) => setgastric(e.target.value)}
                placeholder=""
              >
                <option value={"None"}>-None-</option>
                <option value={"Abdominal Pain"}>Abdominal Pain</option>
                <option value={"GERD"}>GERD</option>
                <option value={"Irritable Bowel Syndrome"}>
                  Irritable Bowel Syndrome
                </option>
              </select>
            </div>
            <div className="head2">
              <button className="form_btn" type="submit">
                Submit
              </button>
            </div>
          </div>
        </form>

        <div className="center">
          <h3 className="head2">Gastric Symptom: {gastric}</h3>
          <h1>{message}</h1>
          <Button
            disabled={!message}
            variant="contained"
            color="success"
            size="large"
            onClick={() => window.open(url, "_blank")}
          >
            See Your Results
          </Button>
        </div>
        <Rating category={"gastric"} disabled={!message} />
      </div>
    </div>
  );
};
export default Gastric;
