import React, { useState } from "react";
import { Button } from "@mui/material";
import Rating from "../Rating";

function Bloodpressure() {
  const [pressure, setPressure] = useState(null);
  const [pressure1, setPressure1] = useState(null);
  const [message, setMessage] = useState("");
  const [url, setUrl] = useState("");

  let calcPressure = (event) => {
    //prevent submitting
    event.preventDefault();

    if (pressure <= 0 || pressure1 <=0) {
      alert("Please enter a valid Blood Pressure");
      
    } else if (pressure === null || pressure1 === null) {
       alert("Please enter a valid Blood Pressure");
      
     }else {
        if (pressure > 0  && pressure <= 90) {
        setUrl(
          "https://firebasestorage.googleapis.com/v0/b/health-info-app-22b13.appspot.com/o/BP%2FLow_BP.pdf?alt=media&token=a3520e5b-49bd-45ab-8fc4-5c569ddf07ce"
        );
        setMessage("Low Blood Pressure");
      } else if (pressure1 > 0 && pressure1 <= 60 ) {
        setUrl(
          "https://firebasestorage.googleapis.com/v0/b/health-info-app-22b13.appspot.com/o/BP%2FLow_BP.pdf?alt=media&token=a3520e5b-49bd-45ab-8fc4-5c569ddf07ce"
        );
        setMessage("Low Blood Pressure");
      }  else if (pressure > 90 && pressure <= 120) {
        setUrl(
          "https://firebasestorage.googleapis.com/v0/b/health-info-app-22b13.appspot.com/o/BP%2FNormal_BP.pdf?alt=media&token=cdd3dbf6-ed7d-4e80-9cc8-e43a5e528ef8"
        );
        setMessage("Normal Blood Pressure");
      
      } else if (pressure1 > 60 && pressure1 <= 80) {
        setUrl(
          "https://firebasestorage.googleapis.com/v0/b/health-info-app-22b13.appspot.com/o/BP%2FNormal_BP.pdf?alt=media&token=cdd3dbf6-ed7d-4e80-9cc8-e43a5e528ef8"
        );
        setMessage("Normal Blood Pressure");   
      }
       else if (pressure > 120 && pressure <= 140) {
        setUrl(
          "https://firebasestorage.googleapis.com/v0/b/health-info-app-22b13.appspot.com/o/BP%2FHigh_BP.pdf?alt=media&token=4304bbb0-fb52-45de-912a-72f051efd7fd"
        );
        setMessage("High Blood Pressure");
      } else if (pressure1 > 80 && pressure1 <= 90) {
        setUrl(
          "https://firebasestorage.googleapis.com/v0/b/health-info-app-22b13.appspot.com/o/BP%2FHigh_BP.pdf?alt=media&token=4304bbb0-fb52-45de-912a-72f051efd7fd"
        );
        setMessage("High Blood Pressure");
      } else if (pressure > 140 && pressure > 90) {
        setUrl(
          "https://firebasestorage.googleapis.com/v0/b/health-info-app-22b13.appspot.com/o/BP%2FHigh_BP.pdf?alt=media&token=4304bbb0-fb52-45de-912a-72f051efd7fd"
        );
        setMessage("High Blood Pressure");
      }
    }
  };

  return (
    <div>
      <div className="container">
        <h2 className="head2">Blood Pressure</h2>
        <form onSubmit={calcPressure} className="p-4 box">
          <div className="form-body">
            <div className="pressure">
              <label className="form__label" for="pressure">
                <b>Blood_Pressure</b>{" "}
              </label>
              <input
                type="number"
                name=""
                id="pressure"
                min={1}
                value={pressure}
                className="form__input"
                onChange={(e) => setPressure(e.target.value)}
                placeholder="Value"
              />
              <span> / </span>
              <input
                type="number"
                name=""
                id="pressure1"
                min={1}
                value={pressure1}
                className="form__input"
                onChange={(e) => setPressure1(e.target.value)}
                placeholder="Value"
              />
              <span> mmHg </span>
            </div>
            <div className="head2">
              <button className="form_btn" type="submit">
                Submit
              </button>
            </div>
          </div>
        </form>

        <div className="center">
          <h1 className="head2">
            Your Blood Pressure is: {pressure}/{pressure1} mmHg{" "}
          </h1>
          <h1>{message}</h1>
          <Button
            disabled={!message}
            variant="contained"
            color="success"
            size="large"
            onClick={() => window.open(url, "_blank")}
          >
            See Your Results
          </Button>
        </div>
        <Rating category={"blood"} disabled={!message} />
      </div>
    </div>
  );
}
export default Bloodpressure;
