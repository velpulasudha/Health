import React, { useState } from "react";
import { Button } from "@mui/material";
// import Bar from "./bmi";
import Rating from "../Rating"

const Bmi = () => {
  // state
  const [weight, setWeight] = useState(null);
  const [height, setHeight] = useState(null);
  const [bmi, setBmi] = useState('');
  const [message, setMessage] = useState("");
  const [url, setUrl] = useState("");

  let calcBmi = (event) => {
    //prevent submitting
    event.preventDefault();

    if (weight <=0 || height <= 0) {
      alert("Please enter a valid weight and height");
    } else if (weight === null || height === null) {
      alert("Please enter a valid weight and height");
    } else {
      let bmi = (weight / ((height * height) / 10000)).toFixed(2);
      setBmi(bmi);

      if (bmi < 18.5) {
        setUrl(
          "https://firebasestorage.googleapis.com/v0/b/health-info-app-22b13.appspot.com/o/BMI%2FBMI_under_wgt.pdf?alt=media&token=95647cc7-4ac8-4ae4-a65d-852056bef106"
        );
        setMessage("Underweight");
      } else if (bmi >= 18.5 && bmi <= 24.9) {
        setUrl(
          "https://firebasestorage.googleapis.com/v0/b/health-info-app-22b13.appspot.com/o/BMI%2FBMI_Healthy_wgt.pdf?alt=media&token=c69370a4-946e-4e89-b82c-5c53f0d4dc57"
        );
        setMessage("Healthy Weight");
      } else if (bmi >= 25 && bmi <= 29.9) {
        setUrl(
          "https://firebasestorage.googleapis.com/v0/b/health-info-app-22b13.appspot.com/o/BMI%2FBMI_Over_wgt.pdf?alt=media&token=686eedde-a0d8-4700-a661-36bd678b8022"
        );
        setMessage("Overweight");
      } else if (bmi >= 30) {
        setUrl(
          "https://firebasestorage.googleapis.com/v0/b/health-info-app-22b13.appspot.com/o/BMI%2FBMI_Obese.pdf?alt=media&token=5fc68a99-6109-48b7-b291-af6f03392561"
        );
        setMessage("Obese");
      }
    }
  };

  console.log(url);

  //  show image based on bmi calculation
  let imgSrc;
  if (bmi < 1) {
    imgSrc = null;
  } else {
    if (bmi < 25) {
      // imgSrc = Bar;
    } else if (bmi >= 25 && bmi < 30) {
      //imgSrc = require('../src/assets/healthy.png')
    } else {
      //imgSrc = require('../src/assets/overweight.png')
    }
  }

  return (
    <div>
      <div className="container">
        <h2 className="head2">BMI Calculator</h2>
        <form onSubmit={calcBmi} className="p-4 box">
          <div className="form-body">
            <div className="weight">
              <label className="form__label" for="weight">
                <b>Weight(kg)</b>{" "}
              </label>
              <input
                type="number"
                name=""
                id="weight"
                value={weight}
                className="form__input"
                onChange={(e) => setWeight(e.target.value)}
                placeholder="Enter Weight"
              />
            </div>
            <div>
              <label className="form__label" for="height">
                <b>Height(Cm) </b>
              </label>
              <input
                type="number"
                name=""
                id="height"
                value={height}
                className="form__input"
                onChange={(event) => setHeight(event.target.value)}
                placeholder="Enter Height"
              />
            </div>
            <div className="head2">
              <button className="form_btn" type="submit">
                Submit
              </button>
            </div>
          </div>
        </form>

        <div className="center">
          <h1 className="head2">Your BMI is: {bmi} kg/cm2</h1>
          <h1>{message}</h1>
          <Button
            disabled={!bmi}
            variant="contained"
            color="success"
            size="large"
            onClick={() => window.open(url, "_blank")}
          >
            See Your Results
          </Button>
        </div>
        <Rating category={"bmi"}  disabled={!bmi}/>
      </div>
    </div>
  );
};
export default Bmi;
