import React, { useState } from "react";
import { Button } from "@mui/material";
import Rating from "../Rating";

const Diabetes = () => {
  const [diabeties, setdiabeties] = useState("None");
  const [url, setUrl] = useState("");
  const [message, setMessage] = useState("");

  let diabetiestype = (event) => {
    event.preventDefault();
    if (diabeties == "None") {
      alert("Please select valid symptom");
    } else if (diabeties === "Type 1 diabetes") {
      setUrl(
        "https://firebasestorage.googleapis.com/v0/b/health-info-app-22b13.appspot.com/o/DB%2FDiabetes_Type1.pdf?alt=media&token=706882d8-dd4f-4ca5-a10d-f57101ef6aa3"
      );
      setMessage("Type 1 diabetes");
    } else if (diabeties === "Type 2 Diabetes") {
      setUrl(
        "https://firebasestorage.googleapis.com/v0/b/health-info-app-22b13.appspot.com/o/DB%2FDiabetes_Type2.pdf?alt=media&token=8ddf5146-e3ed-4edc-8f73-b1ba21b55c87"
      );
      setMessage("Type 2 diabetes");
    }
  };

  return (
    <div>
      <div className="container">
        <b>
          <h2 className="head2">Diabeties</h2>
        </b>
        <form onSubmit={diabetiestype} className="p-4 box">
          <div className="form-body">
            <div className="diabeties">
              <label className="form__label" for="diabeties">
                <b>Diabeties </b>
              </label>

              <select
                type="text"
                onChange={(e) => setdiabeties(e.target.value)}
                placeholder="Select Diebeties Type"
              >
                <option value={"None"}>None</option>
                <option value={"Type 1 diabetes"}>Type 1 diabetes</option>
                <option value={"Type 2 Diabetes"}>Type 2 Diabetes</option>
              </select>
            </div>
            <div className="head2">
              <button className="form_btn" type="submit">
                Submit
              </button>
            </div>
          </div>
        </form>
        <div className="center">
          <h3 className="head2">Diabeties Type: {diabeties}</h3>
          <h3>{message}</h3>
          <Button
            disabled={!message}
            variant="contained"
            color="success"
            size="large"
            onClick={() => window.open(url, "_blank")}
          >
            See Your Results
          </Button>
        </div>
        <Rating category={"diabetes"} disabled={!message}/>
      </div>
    </div>
  );
};
export default Diabetes
