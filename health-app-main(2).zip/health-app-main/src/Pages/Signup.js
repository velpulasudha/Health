import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Alert, Container } from "react-bootstrap";
import { useUserAuth } from "../context/UserAuthContext";
import { createUser } from "../firebase/user";
import {
  FormGroup,
  FormControlLabel,
  Checkbox,
  TextField,
  Button,
  FormControl,
  Select,
  InputLabel,
  MenuItem,
} from "@mui/material";
import emailjs from "emailjs-com";

const Signup = () => {
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [gender, setGender] = useState("Male");
  const [age, setAge] = useState(1);
  const [error, setError] = useState("");
  const [chronicDisease, setChronicDisease] = useState(false);
  const [familyDisease, setFamilyDisease] = useState(false);
  const [smoking, setSmoking] = useState(false);
  const [drinking, setDrinking] = useState(false);
  const [allowNotification, setAllowNotification] = useState(false);
  const [password, setPassword] = useState("");
  const { signUp } = useUserAuth();
  let navigate = useNavigate();

  const handleSubmit = async (e) => {
    setError("");
    try {
      await signUp(email, password);
      await createUser({
        firstName,
        lastName,
        email,
        gender,
        age,
        chronicDisease,
        familyDisease,
        smoking,
        drinking,
        allowNotification,
      });
      if (allowNotification) {
        console.log("ALLOWED");
        await emailjs.send("service_r0cymvo", "template_r5vz98f", {
          to: email,
          name: firstName,
        }, "8AMWv7Z4J14U10EYv");
      }
      navigate("/");
    } catch (err) {
      console.log("ERROR", err);
      setError(err.message);
    }
  };

  return (
    <Container className="pt-4 pb-4" style={{ width: "400px" }}>
      <div className="p-4 box">
        <h2 className="mb-3">Auth Signup</h2>
        {error && <Alert variant="danger">{error}</Alert>}
        <div>
          <div
            style={{
              display: "flex",
              marginBottom: "0.5rem",
              flexDirection: "row",
            }}
          >
            <TextField
              type="text"
              variant="outlined"
              label="First Name"
              style={{ marginRight: "2px" }}
              size="small"
              margin="dense"
              value={firstName}
              onChange={(e) => setFirstName(e.target.value)}
            />
            <TextField
              type="text"
              label="Last Name"
              size="small"
              margin="dense"
              value={lastName}
              onChange={(e) => setLastName(e.target.value)}
            />
          </div>
          <FormGroup className="mb-3" controlId="formBasicEmail">
            <TextField
              type="email"
              label="Email address"
              size="small"
              onChange={(e) => setEmail(e.target.value)}
            />
          </FormGroup>

          <FormGroup controlId="formBasicPassword">
            <TextField
              type="password"
              label="Password"
              size="small"
              className="mb-2"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
            <FormControl fullWidth>
              <InputLabel id="demo-simple-select-label">Gender</InputLabel>
              <Select
                labelId="demo-simple-select-label"
                id="demo-simple-select"
                value={gender}
                size="small"
                label="Gender"
                onChange={(e) => setGender(e.target.value)}
              >
                <MenuItem value={"Male"}>Male</MenuItem>
                <MenuItem value={"Female"}>Female</MenuItem>
              </Select>
              <TextField
                type="number"
                label="Age"
                size="small"
                className="mb-2"
                margin="dense"
                value={age}
                onChange={(e) => setAge(e.target.value)}
              />
            </FormControl>
          </FormGroup>
          <FormGroup>
            <FormControlLabel
              value={chronicDisease}
              onChange={(e) => setChronicDisease(e.target.checked)}
              control={<Checkbox />}
              label="Chronic Diseases"
            />
            <FormControlLabel
              value={familyDisease}
              onChange={(e) => setFamilyDisease(e.target.checked)}
              control={<Checkbox />}
              label="Family History Disease"
            />
            <FormControlLabel
              value={smoking}
              onChange={(e) => setSmoking(e.target.checked)}
              control={<Checkbox />}
              label="Smoking"
            />
            <FormControlLabel
              value={drinking}
              onChange={(e) => setDrinking(e.target.checked)}
              control={<Checkbox />}
              label="Drinking"
            />
            <FormControlLabel
              value={allowNotification}
              onChange={(e) => setAllowNotification(e.target.checked)}
              control={<Checkbox />}
              label="Allow Notifications"
            />
          </FormGroup>

          <div className="d-grid gap-2">
            <Button
              color="success"
              disabled={!(firstName && lastName && email && password)}
              variant="contained"
              type="Submit"
              onClick={handleSubmit}
            >
              Sign up
            </Button>
          </div>
        </div>
      </div>
      <div className="p-4 box mt-3 text-center">
        Already have an account? <Link to="/">Log In</Link>
      </div>
    </Container>
  );
};

export default Signup;
