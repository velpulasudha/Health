import React from "react";

const About = () => {
  
  return (
    <div>
      <h1 className="head2"><b><i>Welcome To the about Page!!!</i></b></h1>
      <br></br>
      <p className="head2"><b><i>This app provided nutrition diet plan and precautions for specific categories.</i></b></p>
    </div>
   
  );
};

export default About;
