import React, { useEffect, useState } from "react";
import Grid from "@mui/material/Grid";
import HeaderCard from "../components/HeaderCard";
import Pregnancy from "../assets/pregnancy.png";
import Covid from "../assets/covid.png";
import Diabetics from "../assets/diabetics.png";
import Thyroid from "../assets/thyroid.png";
import Bloodpressure from "../assets/bloodpressure.png";
import Gastric from "../assets/gastric.png";
import Bmi from "../assets/bmi.png";
import { getCategories } from "../firebase/category";

const Home = () => {
  const [categories, setCategories] = useState([]);
  useEffect(() => {
    const getData = async () => {
      const data = await getCategories();
      setCategories(data);
    };
    getData();
  }, []);
  return (
    <Grid>
      <Grid container component="main" spacing={2} sx={{ padding: "1rem" }}>
        {categories.map((category) => (
          <HeaderCard
            title={category.title}
            url={category.url}
            image={category.photo}
            rating={category.rating}
            number={category.total}
          />
        ))}
      </Grid>
    </Grid>
  );
};

export default Home;
