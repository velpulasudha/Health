import { Container, Row, Col } from "react-bootstrap";
import { Routes, Route } from "react-router-dom";
import "./App.css";
import Home from "./Pages/Home";
import Login from "./Pages/Login";
import Signup from "./Pages/Signup";
import Bloodpressure from "./components/Bloodpressure";
import Navbar from "./components/navbar";
import Bmi from "./components/BMI";
import Covid from "./components/Covid";
import Diabetes from "./components/Diabetes";
import Gastric from "./components/Gastric";
import Thyroid from "./components/Thyroid";
import Pregnancy from "./components/Pregnancy";
import AdminLogin from "./admin/AdminLogin";
// import Logout from "./components/Logout/logout";
import About from "./Pages/About";
import ProtectedRoute from "./components/ProtectedRoute";
import { UserAuthContextProvider } from "./context/UserAuthContext";

function App() {
  return (
    <div>
      <UserAuthContextProvider>
        <Routes>
          <Route
            path="/home"
            element={
              <ProtectedRoute>
                <Home />
              </ProtectedRoute>
            }
          />
          <Route path="/" element={<Login />} />
          <Route path="/admin" element={<AdminLogin />} />
          <Route
            path="/Home"
            element={
              <ProtectedRoute>
                <Home />
              </ProtectedRoute>
            }
          />
          <Route path="/about" element={<ProtectedRoute> <About /> </ProtectedRoute>} />
          <Route path="/signup" element={<Signup />} />
          <Route
            path="/bmi"
            element={
              <ProtectedRoute>
                <Bmi />
              </ProtectedRoute>
            }
          />
          /
          <Route
            path="/covid"
            element={
              <ProtectedRoute>
                <Covid />
              </ProtectedRoute>
            }
          />
          <Route
            path="/diabetes"
            element={
              <ProtectedRoute>
                <Diabetes />
              </ProtectedRoute>
            }
          />
          <Route
            path="/gastric"
            element={
              <ProtectedRoute>
                <Gastric />
              </ProtectedRoute>
            }
          />
          <Route
            path="/thyroid"
            element={
              <ProtectedRoute>
                <Thyroid />
              </ProtectedRoute>
            }
          />
          <Route
            path="/pregnancy"
            element={
              <ProtectedRoute>
                <Pregnancy />
              </ProtectedRoute>
            }
          />
          {/* <Route path="/about" element={<ProtectedRoute> <About /> </ProtectedRoute>} /> */}
          <Route
            path="/bloodpressure"
            element={
              <ProtectedRoute>
                <Bloodpressure />
              </ProtectedRoute>
            }
          />
          {/* <Route path="/navbar" element={<Navb />} /> */}
          {/* <Route path="/logout" element={ <Logout /> } /> */}
        </Routes>
      </UserAuthContextProvider>
    </div>
  );
}

export default App;
